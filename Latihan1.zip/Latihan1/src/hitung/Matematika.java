package hitung;

public class Matematika {
    
    double bil1, bil2;
    double hasil1;
    double hasil2;
    double hasil3;
    double hasil4;
    
    public void Pertambahan(double a, double b){
        hasil1 = a + b;
        System.out.println("Pertambahan= " + a + "+" + b + "=" + hasil1);
    }
    
    public void Pengurangan(double a, double b){
        hasil2 = a - b;
        System.out.println("Pengurangan= " + a + "-" + b + "=" + hasil2);
    }
    
    public void Perkalian(double a, double b){
        hasil3 = a * b;
        System.out.println("Perkalian= " + a + "*" + b + "=" + hasil3);
    }
    
    public void Pembagian(double a, double b){
        hasil4 = a / b;
        System.out.println("Pembagian= " + a + "/" + b + "=" + hasil4);
    }
    
}
