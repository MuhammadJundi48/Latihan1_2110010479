package hitung;

public class MatematikaBeraksi {
    public static void main(String[] args){
        Matematika Jundi = new Matematika();
        
        Jundi.Pertambahan(7, 9);
        Jundi.Pengurangan(7, 9);
        Jundi.Perkalian(7, 9);
        Jundi.Pembagian(7, 9);
        
    }
    
}
